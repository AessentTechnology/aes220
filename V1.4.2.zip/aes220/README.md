This is the source code for the libraries and software used with the aes220 High-Speed USB FPGA.

The binaries and executables can be found on the company's website at: www.aessent.com

There is no Make file to compile the API. However it is relatively straight forward to compile
 as it depends only on libusb. 

The firmware can be built using the Make file provided in the same folder as the source code. 
It requires SDCC to be installed.

The vhdl packages can be used with Xilinx ISE WebPack edition.
